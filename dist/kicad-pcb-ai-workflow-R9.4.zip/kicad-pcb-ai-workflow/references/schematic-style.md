# 项目化原理图结构与图面规则 · R9.3

原理图批量策略推广前另见 [三遍绘制与跨页面原型验证](schematic-cross-archetype.md)。

**原理图设计、重排和逐页审查必须先应用 [拓扑驱动 AI 原理图设计规则](schematic-ai-layout-rules.md) 的 L0–L5 分层、角色表达、冲突裁决与证据矩阵。** 尚未由脚本实现的几何谓词需要真实人工核验，不得称作自动门禁。

按功能模块、连接复杂度、复用和可读性选择单页、多顶层或层次结构。纸张、页数、器件数及居中距离不设通用硬阈值；用户明确要求才写入项目策略。历史88器件/A3/A4固定绑定与默认三层页数撤销。分页方案可以预览；用户已明确方案或授权例行选择时无需重复确认。

分页不由用户先验指定。原理图前置阶段必须先生成系统架构首页，并把模块页/层级与跨模块接口绑定到`system-integration.json`；细节见`system-integration.md`。图面评审按架构首页→模块页→接口端点的顺序核读。

## 实际自动检查

运行schematic_style.py，策略用assets/schematic-style.template.json。解析不依赖缩进，读取全部可达层次子页；拒绝循环、丢失子页、路径越界和符号链接。pages只填明确约束：键为相对页面路径，值可含paper及portrait。约束或require_sheet_pin_wire=true时，source必须含当前file/sha256/locator。

- 页面纸张和方向：仅比较项目明确值，无默认A3/A4。
- 层次映射：父图框引脚集合必须与相应子页hierarchical_label集合一致，图框同名引脚重复阻断。
- 实体互联：仅在require_sheet_pin_wire=true时检查图框引脚接触本页wire线段（允许落在线段中点）。这是几何预筛，不证明整个网络已正确连接；总线连接仅靠本检查不能放行，需原生XML/人工核对，当前选择此模式会对只有bus连接的引脚保守阻断。
- 电源位号：同页#PWR/#FLG重复筛查。复用子页/跨实例的最终注释由原生导出/ERC核对，不把多单元器件当重复器件。

不自动检查或不声称已证明：完整文字包围盒/重叠、所有电源长线、实体外形居中、模块注解完整、引脚悬空是否允许、电气逻辑和原厂推荐电路。以上进入实际AI/工程师逐页评审，不写成已自动完成的S4/S6/S7/S8机器门禁。

## 电气优先与KiCad语义

电源符号有作用域，按实际全局/局部属性判断；不要一律认定电源符号跨全部页面连接。PWR_FLAG只向ERC声明供电来源，不证明供电正确；跨被动滤波后的网段需按真实连接判断。未用脚是否可NC必须先查手册，不能用叉号替代必需上拉/接地/偏置。局部电路优先清楚表达，标签/总线/层次连接按真实项目使用，不因美观改变拓扑。

## 与评审/NPI绑定

新静态配置require_schematic_style=true、schematic_style.policy指向项目策略，并有category=schematic_style、check.kind=semantic任务；策略来源须映射到真实documents及source_refs。static_review生成schematic-style.json，捕获策略/页面/来源哈希；static_review_gate复算并检查基线。AI实际阅读各页图面及连接，工程师确认当前报告。R9 NPI的workflow_contract要求同一策略已在原理图确认包中，不能只运行独立脚本替代签核。
